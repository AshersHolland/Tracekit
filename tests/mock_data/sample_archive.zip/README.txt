synthetic archive member
